# AutoTimestamp Editor (Android)

Project Android Kotlin yang dapat diunggah ke GitHub dan dibangun menjadi APK melalui GitHub Actions.

## Fitur prototipe
- Memilih foto dari perangkat.
- OCR lokal dengan Google ML Kit untuk mencari baris tanggal/waktu yang terlihat.
- Mengisi area watermark yang terdeteksi dan menggambar tanggal/waktu baru.
- Menyimpan hasil sebagai file baru; foto sumber tidak diubah.
- Pemrosesan dilakukan di perangkat setelah dependensi diunduh saat build.

## Batasan penting
- Ini prototipe awal. Deteksi OCR bisa gagal pada watermark kecil, blur, atau format kamera yang tidak umum.
- Pengisian latar menggunakan interpolasi horizontal sederhana, bukan inpainting profesional; latar kompleks dapat terlihat tidak alami.
- Font/ukuran/posisi hasil adalah perkiraan dan tidak bisa dijamin identik dengan watermark bawaan setiap merek kamera.
- Pada Android 10 ke atas, file hasil masuk ke Galeri pada folder `Pictures/AutoTimestamp`. Pada Android versi lebih lama, file disimpan di folder aplikasi.
- Gunakan pengeditan timestamp secara transparan dan jangan menyajikan foto yang diedit seolah-olah bukti asli yang tidak diubah.

## Build lewat GitHub dari HP Android
1. Unduh dan ekstrak ZIP ini.
2. Buat repository GitHub bernama `AutoTimestampEditor`.
3. Unggah **isi folder** proyek yang diekstrak ke repository (jangan hanya mengunggah ZIP).
4. Buka tab **Actions**, pilih **Build AutoTimestamp APK**, lalu tekan **Run workflow** jika belum berjalan otomatis.
5. Tunggu sampai selesai, buka run terbaru, lalu bagian **Artifacts**.
6. Unduh `AutoTimestampEditor-debug-APK`. Di dalamnya ada `app-debug.apk`.

## Requirements
- Android Studio/Gradle build environment (GitHub Actions sudah dikonfigurasi).
- Java 17, Android SDK 35.

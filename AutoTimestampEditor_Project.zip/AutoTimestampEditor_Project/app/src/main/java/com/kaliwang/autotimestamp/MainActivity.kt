package com.kaliwang.autotimestamp

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.provider.MediaStore
import android.content.ContentValues
import android.os.Build
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val pickImage = 101
    private var selectedUri: Uri? = null
    private lateinit var preview: ImageView
    private lateinit var timestampInput: EditText
    private lateinit var status: TextView
    private lateinit var processButton: Button
    private var sourceBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            setBackgroundColor(Color.rgb(247, 248, 246))
        }
        val title = TextView(this).apply {
            text = "AutoTimestamp Editor"
            textSize = 24f
            setTextColor(Color.rgb(24, 75, 54))
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        val subtitle = TextView(this).apply {
            text = "Deteksi watermark tanggal/waktu, ganti pada salinan foto, dan simpan hasil baru."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 14)
            setTextColor(Color.DKGRAY)
        }
        root.addView(subtitle)

        val pick = Button(this).apply {
            text = "1. Pilih foto"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                startActivityForResult(intent, pickImage)
            }
        }
        root.addView(pick, LinearLayout.LayoutParams(-1, -2))

        timestampInput = EditText(this).apply {
            hint = "Tanggal/waktu baru: 25/10/2026 16:30"
            setSingleLine(true)
            textSize = 16f
            setText(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date()))
            setPadding(14, 8, 14, 8)
        }
        root.addView(timestampInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })

        processButton = Button(this).apply {
            text = "2. Deteksi & ganti watermark"
            isEnabled = false
            setOnClickListener { processPhoto() }
        }
        root.addView(processButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })

        status = TextView(this).apply {
            text = "Foto diproses di perangkat. Foto asli tidak diubah."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(2, 10, 2, 10)
        }
        root.addView(status)

        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.LTGRAY)
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 6 })

        val note = TextView(this).apply {
            text = "Catatan: hasil deteksi dan pengisian latar bisa berbeda tergantung foto. Periksa hasil sebelum digunakan. Gunakan secara transparan; aplikasi tidak menjamin font identik dengan kamera asli."
            textSize = 11f
            setTextColor(Color.GRAY)
            setPadding(0, 10, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    @Deprecated("Deprecated in Android API but kept for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { stream ->
                    val original = BitmapFactory.decodeStream(stream) ?: error("Foto tidak dapat dibaca")
                    sourceBitmap = original.copy(Bitmap.Config.ARGB_8888, true)
                    selectedUri = uri
                    preview.setImageBitmap(sourceBitmap)
                    processButton.isEnabled = true
                    status.text = "Foto dipilih. Masukkan tanggal/waktu baru lalu jalankan deteksi."
                }
            } catch (e: Exception) {
                status.text = "Gagal membuka foto: ${e.message}"
            }
        }
    }

    private fun processPhoto() {
        val bitmap = sourceBitmap ?: return
        val newText = timestampInput.text.toString().trim()
        if (!Regex("""\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}""").matches(newText)) {
            timestampInput.error = "Format harus dd/MM/yyyy HH:mm"
            return
        }
        processButton.isEnabled = false
        status.text = "Sedang mendeteksi watermark…"
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                try {
                    val candidate = result.textBlocks
                        .flatMap { it.lines }
                        .mapNotNull { line ->
                            val t = line.text.replace(" ", "")
                            val looksLikeDate = Regex("""\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}""").containsMatchIn(t)
                            val looksLikeTime = Regex("""\d{1,2}:\d{2}""").containsMatchIn(t)
                            if (looksLikeDate || (looksLikeTime && line.boundingBox != null)) line else null
                        }
                        .maxByOrNull { line ->
                            val r = line.boundingBox!!
                            (r.bottom.toFloat() / bitmap.height) + if (Regex("""\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}""").containsMatchIn(line.text)) 1f else 0f
                        }
                    if (candidate == null || candidate.boundingBox == null) {
                        status.text = "Tanggal/waktu tidak terdeteksi otomatis. Coba foto yang watermark-nya jelas dan tidak tertutup."
                        processButton.isEnabled = true
                        return@addOnSuccessListener
                    }
                    val rect = candidate.boundingBox!!
                    val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                    val padX = max(8, (rect.height() * 0.28f).toInt())
                    val padY = max(5, (rect.height() * 0.20f).toInt())
                    val box = Rect(
                        max(0, rect.left - padX),
                        max(0, rect.top - padY),
                        min(output.width, rect.right + padX),
                        min(output.height, rect.bottom + padY)
                    )
                    fillByHorizontalInterpolation(output, box)
                    drawReplacement(output, newText, rect, rect.height().toFloat())
                    saveOutput(output)
                    preview.setImageBitmap(output)
                    status.text = "Selesai. Hasil disimpan sebagai foto baru di Pictures/AutoTimestamp. Foto asli tetap utuh."
                } catch (e: Exception) {
                    status.text = "Gagal memproses foto: ${e.message}"
                } finally {
                    processButton.isEnabled = true
                    recognizer.close()
                }
            }
            .addOnFailureListener { e ->
                status.text = "Deteksi gagal: ${e.message}"
                processButton.isEnabled = true
                recognizer.close()
            }
    }

    // Fills the detected strip by interpolating pixels from its left and right edges.
    // This is a lightweight fallback rather than a perfect reconstruction of the background.
    private fun fillByHorizontalInterpolation(bitmap: Bitmap, rect: Rect) {
        val w = bitmap.width
        val h = bitmap.height
        val leftX = max(0, rect.left - 1)
        val rightX = min(w - 1, rect.right)
        val width = rect.width()
        if (width <= 0) return
        for (y in rect.top until rect.bottom.coerceAtMost(h)) {
            val left = bitmap.getPixel(leftX, y)
            val right = bitmap.getPixel(rightX, y)
            val lr = Color.red(left); val lg = Color.green(left); val lb = Color.blue(left)
            val rr = Color.red(right); val rg = Color.green(right); val rb = Color.blue(right)
            for (x in rect.left until rect.right.coerceAtMost(w)) {
                val ratio = (x - rect.left).toFloat() / max(1, width)
                val r = (lr + (rr - lr) * ratio).toInt().coerceIn(0,255)
                val g = (lg + (rg - lg) * ratio).toInt().coerceIn(0,255)
                val b = (lb + (rb - lb) * ratio).toInt().coerceIn(0,255)
                bitmap.setPixel(x, y, Color.rgb(r,g,b))
            }
        }
    }

    private fun drawReplacement(bitmap: Bitmap, text: String, rect: Rect, detectedHeight: Float) {
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            color = Color.WHITE
            textSize = max(12f, detectedHeight * 0.92f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setShadowLayer(max(1f, detectedHeight * 0.08f), 1f, 1f, Color.BLACK)
        }
        // Keep the new text close to the detected watermark's baseline.
        val x = rect.left.toFloat()
        val baseline = min(bitmap.height - 2f, rect.bottom.toFloat() - max(1f, detectedHeight * 0.08f))
        canvas.drawText(text, x, baseline, paint)
    }

    private fun saveOutput(bitmap: Bitmap) {
        val name = "AutoTimestamp_${System.currentTimeMillis()}.jpg"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoTimestamp")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Tidak bisa membuat file hasil")
            contentResolver.openOutputStream(uri).use { stream ->
                if (stream == null) error("Tidak bisa membuka file hasil")
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
        } else {
            val dir = File(getExternalFilesDir(null), "AutoTimestamp")
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, name)
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
        }
    }
}

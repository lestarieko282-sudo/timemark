# Auto Timestamp Editor — Android starter project

Proyek awal Kotlin untuk memilih foto, memilih tanggal/waktu, mencoba membersihkan watermark di kanan bawah, lalu menambahkan timestamp baru dan menyimpan salinan.

## Penting
- Ini adalah **prototipe awal**, bukan penghapus watermark sempurna.
- Deteksi watermark saat ini memakai area kanan bawah dan ambang piksel terang. Pada latar terang/rumit, sebagian latar bisa ikut terhapus atau watermark lama bisa tersisa.
- Font asli kamera belum bisa dipastikan otomatis dari satu foto. Ukuran/font baru adalah perkiraan yang perlu dituning lewat pengujian.
- Foto sumber sebaiknya dicadangkan. Aplikasi menyimpan hasil sebagai file baru, tetapi tombol proses mengganti pratinjau aktif.
- Aplikasi memerlukan koneksi internet saat Gradle pertama kali mengunduh dependensi.

## Build
Buka folder ini di Android Studio, tunggu Gradle Sync, lalu Build > Build APK(s).
Target: Android SDK 35, minimum Android 8.0 (API 26).

## Rencana pengembangan
1. Tambahkan OCR untuk menemukan teks timestamp secara lebih tepat.
2. Buat mask khusus pada huruf, bukan semua piksel terang di sudut.
3. Kalibrasi ukuran/font/posisi berdasarkan kamera sumber.
4. Tambahkan preview sebelum/sesudah dan undo.
5. Uji pada beberapa foto dengan latar berbeda.

## Catatan build
Versi Android Gradle Plugin dan dependensi OpenCV mungkin perlu penyesuaian sesuai lingkungan build yang dipakai.

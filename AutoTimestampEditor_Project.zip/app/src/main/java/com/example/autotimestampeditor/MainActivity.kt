package com.example.autotimestampeditor

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import org.opencv.android.OpenCVLoader
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private var sourceBitmap: Bitmap? = null
    private var sourceUri: Uri? = null
    private lateinit var preview: ImageView
    private lateinit var dateButton: Button
    private lateinit var timeButton: Button
    private lateinit var status: TextView
    private val calendar = Calendar.getInstance()
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.US)
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.US)

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    sourceBitmap = BitmapFactory.decodeStream(input)?.copy(Bitmap.Config.ARGB_8888, true)
                }
                sourceUri = uri
                preview.setImageBitmap(sourceBitmap)
                status.text = "Foto dipilih. Masukkan tanggal/waktu, lalu tekan Proses Foto."
            } catch (e: Exception) {
                status.text = "Gagal membuka foto: ${e.message}"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
        }
        val title = TextView(this).apply {
            text = "Auto Timestamp Editor"
            textSize = 24f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.LTGRAY)
        }
        val pick = Button(this).apply {
            text = "Pilih Foto"
            setOnClickListener { imagePicker.launch("image/*") }
        }
        dateButton = Button(this).apply {
            text = "Tanggal: ${dateFormat.format(calendar.time)}"
            setOnClickListener {
                DatePickerDialog(this@MainActivity, { _, y, m, d ->
                    calendar.set(y, m, d)
                    text = "Tanggal: ${dateFormat.format(calendar.time)}"
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
            }
        }
        timeButton = Button(this).apply {
            text = "Waktu: ${timeFormat.format(calendar.time)}"
            setOnClickListener {
                TimePickerDialog(this@MainActivity, { _, h, m ->
                    calendar.set(Calendar.HOUR_OF_DAY, h)
                    calendar.set(Calendar.MINUTE, m)
                    text = "Waktu: ${timeFormat.format(calendar.time)}"
                }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true).show()
            }
        }
        val process = Button(this).apply {
            text = "Proses Foto"
            setOnClickListener { processPhoto() }
        }
        val save = Button(this).apply {
            text = "Simpan Foto Hasil"
            setOnClickListener { savePhoto() }
        }
        status = TextView(this).apply {
            text = "Pilih foto untuk memulai."
            textSize = 14f
            setPadding(0, 8, 0, 8)
        }
        root.addView(title)
        root.addView(pick)
        root.addView(dateButton)
        root.addView(timeButton)
        root.addView(process)
        root.addView(save)
        root.addView(status)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (!OpenCVLoader.initLocal()) status.text = "OpenCV belum siap. Periksa koneksi dan dependensi saat build."
    }

    private fun processPhoto() {
        val original = sourceBitmap
        if (original == null) {
            status.text = "Pilih foto terlebih dahulu."
            return
        }
        try {
            // MVP: assume timestamp is in the lower-right corner, similar to the sample.
            // The mask is deliberately limited to a small corner region to reduce collateral changes.
            val bitmap = original.copy(Bitmap.Config.ARGB_8888, true)
            val w = bitmap.width
            val h = bitmap.height
            val roiLeft = (w * 0.66f).toInt().coerceAtLeast(0)
            val roiTop = (h * 0.88f).toInt().coerceAtLeast(0)
            val roiWidth = w - roiLeft
            val roiHeight = h - roiTop

            val pixels = IntArray(w * h)
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
            val maskBytes = ByteArray(w * h)
            // Approximate the white timestamp by selecting bright, low-saturation pixels in the ROI.
            for (y in roiTop until h) {
                for (x in roiLeft until w) {
                    val c = pixels[y * w + x]
                    val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                    val maxC = maxOf(r, g, b)
                    val minC = minOf(r, g, b)
                    if (minOf(r, g, b) > 165 && (maxC - minC) < 55) {
                        maskBytes[y * w + x] = 255.toByte()
                    }
                }
            }
            val src = Mat(h, w, CvType.CV_8UC4)
            val rgba = ByteArray(w * h * 4)
            var i = 0
            for (c in pixels) {
                rgba[i++] = Color.red(c).toByte()
                rgba[i++] = Color.green(c).toByte()
                rgba[i++] = Color.blue(c).toByte()
                rgba[i++] = Color.alpha(c).toByte()
            }
            src.put(0, 0, rgba)
            val mask = Mat(h, w, CvType.CV_8UC1)
            mask.put(0, 0, maskBytes)
            val bgr = Mat()
            Imgproc.cvtColor(src, bgr, Imgproc.COLOR_RGBA2RGB)
            val out = Mat()
            Photo.inpaint(bgr, mask, out, 3.0, Photo.INPAINT_TELEA)
            val outRgb = ByteArray(w * h * 3)
            out.get(0, 0, outRgb)
            val cleaned = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val outPixels = IntArray(w * h)
            i = 0
            for (p in outPixels.indices) {
                val r = outRgb[i++].toInt() and 255
                val g = outRgb[i++].toInt() and 255
                val b = outRgb[i++].toInt() and 255
                outPixels[p] = Color.rgb(r, g, b)
            }
            cleaned.setPixels(outPixels, 0, w, 0, 0, w, h)

            val canvas = Canvas(cleaned)
            val text = "${dateFormat.format(calendar.time)} ${timeFormat.format(calendar.time)}"
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.RIGHT
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                // Scaled relative to image dimensions; tune once tested on the target camera.
                textSize = (w * 0.023f).coerceIn(18f, 64f)
                setShadowLayer(0.8f, 0.5f, 0.5f, Color.argb(70, 0, 0, 0))
            }
            val x = w - w * 0.035f
            val y = h - h * 0.035f
            canvas.drawText(text, x, y, paint)
            sourceBitmap = cleaned
            preview.setImageBitmap(cleaned)
            status.text = "Selesai. Periksa hasilnya sebelum disimpan. Ini versi awal: deteksi dan pemulihan latar belakang masih perkiraan."
            src.release(); mask.release(); bgr.release(); out.release()
        } catch (e: Exception) {
            status.text = "Pemrosesan gagal: ${e.message}. Pastikan OpenCV berhasil dimuat."
        }
    }

    private fun savePhoto() {
        val bitmap = sourceBitmap
        if (bitmap == null) {
            status.text = "Belum ada foto untuk disimpan."
            return
        }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Timestamp_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoTimestampEditor")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file tujuan")
            contentResolver.openOutputStream(uri)?.use { output ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 98, output)
            }
            status.text = "Foto hasil disimpan di Pictures/AutoTimestampEditor."
        } catch (e: Exception) {
            status.text = "Gagal menyimpan foto: ${e.message}"
        }
    }
}

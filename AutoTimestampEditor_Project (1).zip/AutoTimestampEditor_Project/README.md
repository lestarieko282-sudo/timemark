# AutoTimestamp Editor

Proyek Android Kotlin untuk membuat APK melalui GitHub Actions. Antarmuka dan panduan menggunakan bahasa Indonesia.

## Fitur prototipe
- Ikon aplikasi hijau tua dan emas disertakan pada resource mipmap.
- Memilih foto dari Galeri Android.
- OCR lokal (Google ML Kit) untuk mencari baris tanggal/waktu yang tampak pada foto.
- Memasukkan tanggal/waktu baru dengan format `dd/MM/yyyy HH:mm`.
- Menyimpan hasil sebagai file JPEG baru; foto sumber tidak ditimpa.
- Android 10+ menyimpan hasil di Galeri pada `Pictures/AutoTimestamp`.

## Batasan yang perlu diketahui
Ini adalah prototipe awal. Deteksi OCR bisa gagal pada watermark kecil, buram, atau format tidak umum. Penghapusan watermark memakai interpolasi sederhana antara piksel di sisi kiri dan kanan, bukan inpainting profesional. Jika watermark menimpa latar rumit, hasil bisa tampak tidak alami. Font, ukuran, bayangan, dan posisi yang digambar adalah perkiraan, bukan jaminan identik dengan watermark asli.

Gunakan pengeditan timestamp secara transparan; jangan menyajikan foto yang diedit sebagai bukti asli yang tidak diubah.

## Build APK melalui GitHub dari HP Android

**Penting:** GitHub tidak mengekstrak ZIP yang diunggah sebagai file biasa. Ekstrak ZIP ini di HP, kemudian unggah **isi folder proyek** ke repository GitHub agar workflow `.github/workflows/build-apk.yml` ikut terunggah.

1. Unduh ZIP proyek dan ekstrak menggunakan aplikasi File/Files di HP.
2. Buat repository GitHub bernama `AutoTimestampEditor`.
3. Di repository, pilih **Add file → Upload files** dan unggah isi folder hasil ekstrak. Pastikan folder `.github/workflows` ikut terunggah.
4. Buka tab **Actions** dan pilih **Build AutoTimestamp APK**. Jika perlu tekan **Run workflow**.
5. Setelah proses berhasil, buka run terbaru dan cari **Artifacts**.
6. Unduh `AutoTimestampEditor-debug-APK`, ekstrak hasil unduhan, lalu pasang `app-debug.apk` di HP.

## Versi teknis
- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.9 di GitHub Actions
- compileSdk 35, minSdk 23

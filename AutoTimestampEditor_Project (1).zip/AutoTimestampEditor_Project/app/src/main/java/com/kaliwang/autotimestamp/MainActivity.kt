package com.kaliwang.autotimestamp

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private var sourceBitmap: Bitmap? = null
    private var sourceUri: Uri? = null
    private var detectedRect: Rect? = null
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var timestampInput: EditText
    private lateinit var saveButton: Button

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadPhoto(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            setBackgroundColor(Color.rgb(245, 248, 246))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "AutoTimestamp Editor"
            textSize = 24f
            setTextColor(Color.rgb(14, 76, 52))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Ubah tanggal/waktu yang terlihat pada foto. Foto asli tidak diubah."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(dp(4), 0, dp(4), dp(12))
        }
        val chooseButton = Button(this).apply {
            text = "Pilih Foto"
            setOnClickListener { pickImage.launch("image/*") }
        }
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(228, 233, 230))
            contentDescription = "Pratinjau foto"
        }
        val previewParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280))
        previewParams.setMargins(0, dp(8), 0, dp(8))
        val label = TextView(this).apply {
            text = "Tanggal/waktu baru (dd/MM/yyyy HH:mm)"
            textSize = 14f
            setTextColor(Color.rgb(35, 48, 40))
        }
        timestampInput = EditText(this).apply {
            hint = "25/10/2026 16:30"
            setSingleLine(true)
            setText(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date()))
            inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_NORMAL
        }
        val detectButton = Button(this).apply {
            text = "Deteksi Watermark"
            setOnClickListener { detectTimestamp() }
        }
        saveButton = Button(this).apply {
            text = "Simpan Foto Hasil"
            isEnabled = false
            setOnClickListener { processAndSave() }
        }
        status = TextView(this).apply {
            text = "Pilih foto untuk mulai."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(dp(2), dp(8), dp(2), dp(8))
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(chooseButton)
        content.addView(preview, previewParams)
        content.addView(label)
        content.addView(timestampInput)
        content.addView(detectButton)
        content.addView(saveButton)
        content.addView(status)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }

    private fun loadPhoto(uri: Uri) {
        try {
            contentResolver.openInputStream(uri).use { input ->
                val bitmap = BitmapFactory.decodeStream(input) ?: throw IllegalArgumentException("Foto tidak dapat dibaca")
                sourceBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                sourceUri = uri
                detectedRect = null
                preview.setImageBitmap(sourceBitmap)
                saveButton.isEnabled = false
                status.text = "Foto dimuat. Tekan Deteksi Watermark."
            }
        } catch (e: Exception) {
            toast("Gagal membuka foto: ${e.message ?: "format tidak didukung"}")
        }
    }

    private fun detectTimestamp() {
        val bitmap = sourceBitmap
        if (bitmap == null) {
            toast("Pilih foto terlebih dahulu.")
            return
        }
        status.text = "Sedang membaca tulisan pada foto…"
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val lines = result.textBlocks.flatMap { it.lines }.filter { it.boundingBox != null }
                val dateRegex = Regex("(?i)(\\b\\d{1,2}[./-]\\d{1,2}[./-]\\d{2,4}\\b|\\b\\d{4}[./-]\\d{1,2}[./-]\\d{1,2}\\b)")
                val timeRegex = Regex("\\b\\d{1,2}:\\d{2}(:\\d{2})?\\b")
                val candidate = lines.firstOrNull { dateRegex.containsMatchIn(it.text) && timeRegex.containsMatchIn(it.text) }
                    ?: lines.firstOrNull { dateRegex.containsMatchIn(it.text) }
                    ?: lines.firstOrNull { timeRegex.containsMatchIn(it.text) }
                if (candidate == null) {
                    detectedRect = null
                    saveButton.isEnabled = false
                    status.text = "Tanggal/waktu tidak terdeteksi. Coba foto yang lebih jelas atau gunakan foto dengan watermark yang lebih besar."
                } else {
                    var box = Rect(candidate.boundingBox!!)
                    // Combine a nearby date or time line when OCR places them on separate rows.
                    val companion = lines.firstOrNull { line ->
                        line !== candidate && (dateRegex.containsMatchIn(line.text) || timeRegex.containsMatchIn(line.text)) &&
                            kotlin.math.abs(line.boundingBox!!.centerY() - box.centerY()) < max(box.height(), line.boundingBox!!.height()) * 2.2
                    }
                    if (companion != null && ((dateRegex.containsMatchIn(candidate.text) != dateRegex.containsMatchIn(companion.text)) || (timeRegex.containsMatchIn(candidate.text) != timeRegex.containsMatchIn(companion.text)))) {
                        box.union(companion.boundingBox!!)
                    }
                    val padX = max(3, box.height() / 5)
                    val padY = max(2, box.height() / 8)
                    box.inset(-padX, -padY)
                    box.left = box.left.coerceAtLeast(0)
                    box.top = box.top.coerceAtLeast(0)
                    box.right = box.right.coerceAtMost(bitmap.width)
                    box.bottom = box.bottom.coerceAtMost(bitmap.height)
                    detectedRect = box
                    saveButton.isEnabled = true
                    status.text = "Watermark terdeteksi: \"${candidate.text}\". Periksa kotak area yang dipilih sebelum menyimpan."
                    preview.setImageBitmap(drawDetectionOutline(bitmap, box))
                }
                recognizer.close()
            }
            .addOnFailureListener { e ->
                recognizer.close()
                status.text = "OCR gagal: ${e.localizedMessage ?: "coba foto lain"}"
            }
    }

    private fun drawDetectionOutline(bitmap: Bitmap, rect: Rect): Bitmap {
        val copy = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        Canvas(copy).drawRect(RectF(rect), Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 190, 0)
            style = Paint.Style.STROKE
            strokeWidth = max(2f, bitmap.width / 500f)
        })
        return copy
    }

    private fun processAndSave() {
        val original = sourceBitmap ?: return
        val rect = detectedRect ?: run { toast("Deteksi watermark dahulu."); return }
        val newText = timestampInput.text.toString().trim()
        if (!Regex("^\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}$").matches(newText)) {
            toast("Gunakan format dd/MM/yyyy HH:mm, contoh 25/10/2026 16:30")
            return
        }
        try {
            val result = original.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(result)
            val safeRect = Rect(rect)
            fillWithInterpolatedBackground(result, safeRect)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.LEFT
                textSize = (safeRect.height() * 0.76f).coerceIn(10f, 96f)
                setShadowLayer(max(1f, textSize * 0.09f), 1f, 1f, Color.BLACK)
                typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            }
            val availableWidth = max(1, safeRect.width() - dp(2))
            if (paint.measureText(newText) > availableWidth) paint.textSize *= availableWidth / paint.measureText(newText)
            val baseline = safeRect.top + (safeRect.height() - (paint.descent() + paint.ascent())) / 2f
            canvas.drawText(newText, safeRect.left.toFloat(), baseline, paint)
            val savedUri = saveBitmap(result)
            preview.setImageBitmap(result)
            status.text = "Berhasil disimpan sebagai foto baru: $savedUri\nCatatan: hasil penghapusan latar dan font merupakan perkiraan."
            toast("Foto hasil berhasil disimpan.")
        } catch (e: Exception) {
            toast("Gagal menyimpan foto: ${e.localizedMessage ?: "kesalahan tidak diketahui"}")
        }
    }

    private fun fillWithInterpolatedBackground(bitmap: Bitmap, rect: Rect) {
        val left = (rect.left - 2).coerceAtLeast(0)
        val right = (rect.right + 2).coerceAtMost(bitmap.width - 1)
        val top = rect.top.coerceAtLeast(0)
        val bottom = rect.bottom.coerceAtMost(bitmap.height - 1)
        for (y in top..bottom) {
            val leftColor = bitmap.getPixel(left, y)
            val rightColor = bitmap.getPixel(right, y)
            val span = max(1, right - left)
            for (x in rect.left.coerceAtLeast(0)..rect.right.coerceAtMost(bitmap.width - 1)) {
                val t = ((x - left).toFloat() / span).coerceIn(0f, 1f)
                val r = (Color.red(leftColor) * (1f - t) + Color.red(rightColor) * t).toInt()
                val g = (Color.green(leftColor) * (1f - t) + Color.green(rightColor) * t).toInt()
                val b = (Color.blue(leftColor) * (1f - t) + Color.blue(rightColor) * t).toInt()
                bitmap.setPixel(x, y, Color.rgb(r, g, b))
            }
        }
    }

    private fun saveBitmap(bitmap: Bitmap): Uri {
        val filename = "AutoTimestamp_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AutoTimestamp")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak bisa membuat file foto")
        try {
            val stream: OutputStream = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Tidak bisa membuka file hasil")
            stream.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val finish = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                contentResolver.update(uri, finish, null, null)
            }
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        }
        return uri
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
